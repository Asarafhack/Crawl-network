import requests
from bs4 import BeautifulSoup
import urllib.parse
from colorama import init, Fore, Back, Style
import tkinter as tk
from tkinter import scrolledtext

# Initialize colorama
init(autoreset=True)

def print_banner():
    banner = """
  ____            _          _           _       
 |  _ \ ___  _ __| |_   _ ___| |__   __ _| |_ ___  
 | |_) / _ \| '__| | | | / __| '_ \ / _` | __/ _ \ 
 |  _ < (_) | |  | | |_| \__ \ | | | (_| | || (_) |
 |_| \_\___/|_|  |_|\__,_|___/_| |_|\__,_|\__\___/ 
                                                  
            Hacker - Asaraf's Web Crawler Tool
    """
    print(Fore.RED + banner)

def get_url_parameters(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check for HTTP errors
        soup = BeautifulSoup(response.content, 'html.parser')
        urls = set()

        # Extract all links from the page
        for link in soup.find_all('a', href=True):
            full_url = urllib.parse.urljoin(url, link['href'])
            parsed_url = urllib.parse.urlparse(full_url)
            if parsed_url.query:
                urls.add(full_url)

        # Extract URL parameters
        parameters = {}
        for url in urls:
            parsed_url = urllib.parse.urlparse(url)
            query_params = urllib.parse.parse_qs(parsed_url.query)
            parameters[url] = query_params

        return parameters

    except requests.RequestException as e:
        print(Fore.RED + f"An error occurred: {e}")
        return {}

def save_to_file(parameters, filename):
    try:
        with open(filename, 'w') as f:
            for url, params in parameters.items():
                f.write(f"URL: {url}\n")
                for key, value in params.items():
                    f.write(f"  {key}: {', '.join(value)}\n")
                f.write("\n")
        print(Fore.GREEN + f"Results saved to {filename}")
    except IOError as e:
        print(Fore.RED + f"An error occurred while writing to the file: {e}")

def show_results_in_window(filename):
    window = tk.Tk()
    window.title("Hacker - Asaraf's Web Crawler Tool Results")
    window.configure(bg='black')

    text_area = scrolledtext.ScrolledText(window, wrap=tk.WORD, width=80, height=30, bg='black', fg='green', font=("Courier", 12))
    text_area.grid(column=0, row=0, padx=10, pady=10)

    with open(filename, 'r') as file:
        text_area.insert(tk.END, file.read())

    text_area.config(state=tk.DISABLED)
    
    window.mainloop()

def main():
    print_banner()

    while True:
        url = input(Fore.CYAN + "Enter the application URL: " + Style.RESET_ALL)
        print(Fore.YELLOW + "Processing..." + Style.RESET_ALL)
        parameters = get_url_parameters(url)

        if not parameters:
            print(Fore.RED + "No parameters found." + Style.RESET_ALL)
            choice = input(Fore.MAGENTA + "Options: \n1. Try a new link\n2. Exit\nEnter your choice (1/2): " + Style.RESET_ALL)
            if choice == '1':
                continue
            elif choice == '2':
                print(Fore.GREEN + "Exiting..." + Style.RESET_ALL)
                break
            else:
                print(Fore.RED + "Invalid choice. Exiting..." + Style.RESET_ALL)
                break
        else:
            filename = input(Fore.GREEN + "Enter the output file name: " + Style.RESET_ALL)
            save_to_file(parameters, filename)

            while True:
                print(Fore.CYAN + "\nOptions:" + Style.RESET_ALL)
                print(Fore.YELLOW + "1. Show results" + Style.RESET_ALL)
                print(Fore.MAGENTA + "2. Try a new link" + Style.RESET_ALL)
                print(Fore.GREEN + "3. Exit" + Style.RESET_ALL)
                choice = input(Fore.MAGENTA + "Enter your choice (1/2/3): " + Style.RESET_ALL)

                if choice == '1':
                    show_results_in_window(filename)
                elif choice == '2':
                    break  # Break out of inner loop to get a new URL
                elif choice == '3':
                    print(Fore.GREEN + "Exiting..." + Style.RESET_ALL)
                    return  # Exit the main function and terminate the program
                else:
                    print(Fore.RED + "Invalid choice. Please enter 1, 2, or 3." + Style.RESET_ALL)

if __name__ == "__main__":
    main()
